package com.vimeo.vimeo_upload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VimeoUploadApplicationTests {

    @Test
    void contextLoads() {
    }

}
