package com.vimeo.vimeo_upload;

public class VimeoException extends Exception {

    public VimeoException(String message) {
        super(message);
    }

}
