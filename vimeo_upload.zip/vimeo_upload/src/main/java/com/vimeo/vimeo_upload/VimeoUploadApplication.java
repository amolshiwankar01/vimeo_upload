package com.vimeo.vimeo_upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;

@SpringBootApplication
public class VimeoUploadApplication {

    public static void main(String[] args) {
        SpringApplication.run(VimeoUploadApplication.class, args);

        /*
        * */

        try {
            Vimeo vimeo = new Vimeo("0beb716e61b44cc64a13ffd9d8a49a48");
            //add a video
            boolean upgradeTo1080 = true;
            String videoEndPoint = vimeo.addVideo(new File("E://PI_PROJECT/video.AVI"), upgradeTo1080);

            //get video info
//            VimeoResponse info = vimeo.getVideoInfo(videoEndPoint);
//            System.out.println(info);
//
//            //edit video
//            String name = "Name";
//            String desc = "Description";
//            String license = ""; //see Vimeo API Documentation
//            String privacyView = "disable"; //see Vimeo API Documentation
//            String privacyEmbed = "whitelist"; //see Vimeo API Documentation
//            boolean reviewLink = false;
//            vimeo.updateVideoMetadata(videoEndPoint, name, desc, license, privacyView, privacyEmbed, reviewLink);
//
//            //add video privacy domain
//            vimeo.addVideoPrivacyDomain(videoEndPoint, "clickntap.com");
//
//            //delete video
//            vimeo.removeVideo(videoEndPoint);

        } catch (Exception e){
            System.out.println("Exception :" + e.getMessage());
        }


    }

}
