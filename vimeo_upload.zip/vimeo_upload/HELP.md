# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.4.0/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.4.0/maven-plugin/reference/html/#build-image)


1. Create Account in vimeo
2. Go to https://developer.vimeo.com/apps - my app page
3. create an app - vimeoApp - back to my app page
4. Click vimeoApp that u have created
5. Permissions 
Upload Access
Request Upload Access (click to it to get enable upload access)
Video File Access
6. after wii get mail for enable upload access approved on inbox
7. Generate an access token - with all 
Scopes :
Public (required)
Private
Purchased
Create
Edit
Delete
Interact
Upload
Promo Codes
Video Files

8. apply access token in your code.
